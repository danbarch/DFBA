#' Classes for DFBA
#'
#'
#' @export
setClass("dfba_gamma_out", representation("list"))
#'
#' @export
setClass("dfba_phi_out", representation("list"))
#'
#' @export
setClass("dfba_phi_star_out", representation("list"))
